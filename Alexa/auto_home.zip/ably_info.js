/*
 * Info about authentication for ABLY.
 */

ABLY_CHAN = "AH_Main";
ABLY_KEY = "NtYGvg.lADLCg:_YcwQxp-lniZ_xWY";
ABLY_AUTH = "Basic UVlpQ1pBLm5kVFQ5dzpmdVdzdDJXSXV2UlYtWDk0"; 


module.exports = {
    ABLY_CHAN: ABLY_CHAN,
    ABLY_KEY: ABLY_KEY,
    ABLY_AUTH: ABLY_AUTH
};
