/*
 * Ably info.
 */

const ABLY_CHAN = "AH_Test";
const ABLY_KEY  = "NtYGvg.lADLCg:_YcwQxp-lniZ_xWY";


module.exports = {
    ABLY_CHAN: ABLY_CHAN,
    ABLY_KEY: ABLY_KEY,
};
