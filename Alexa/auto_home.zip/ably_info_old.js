/*
 * Ably channel and API key.
 */

function define(name, value) {
    Object.defineProperty(exports, name, {
        value:      value,
        enumerable: true
    });
}

define("ABLY_CHAN", "AH_Test");
define("ABLY_KEY", "NtYGvg.lADLCg:_YcwQxp-lniZ_xWY");
