# AutoHome
Home automation using RPi, and Amazon Alexa.
