var PubNub = requrie('pubnub');

/**
 * Pass the data to send as `event.data`, and the request options as
 * `event.options`. For more information see the HTTPS module documentation
 * at https://nodejs.org/api/https.html.
 *
 * Will succeed with the response body.
 */
exports.handler = (event, context, callback) => {

    pubnub = new PubNub({
        publishKey : "pub-c-7e9eb7ff-6ec8-4486-b03f-e0f68291b14c",
        subscribeKey : "sub-c-906b4314-7409-11e7-91f5-0619f8945a4f"
    });

    console.log("Begin publish");
    var publishConfig = {
        channel: "auto_home_channel",
        message: event.data
    };

    pubnub.publish(publishConfig, function(status, response) {
            console.log(status, response);
            return response;
    });



    /*const req = https.request(event.options, (res) => {
        let body = '';
        console.log('Status:', res.statusCode);
        console.log('Headers:', JSON.stringify(res.headers));
        res.setEncoding('utf8');
        res.on('data', (chunk) => body += chunk);
        res.on('end', () => {
            console.log('Successfully processed HTTPS response');
            // If we know it's JSON, parse it
            if (res.headers['content-type'] === 'application/json') {
                body = JSON.parse(body);
            }
            callback(null, body);
        });
    });
    req.on('error', callback);
    req.write(JSON.stringify(event.data));
    req.end();*/
};
